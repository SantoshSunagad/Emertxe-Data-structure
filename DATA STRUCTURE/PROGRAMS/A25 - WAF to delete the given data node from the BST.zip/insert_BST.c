#include "tree.h"

/* Function to insert the data's in BST */
int insert_into_BST(Tree_t **root, int data)
{
    Tree_t *new=malloc(sizeof(Tree_t));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->left=NULL;
    new->right=NULL;
    
    if(*root==NULL)
    {
        *root=new;
        return SUCCESS;
    }
    Tree_t *temp=*root;
    Tree_t *parent=NULL;
    while(temp!=NULL)
    {
        parent=temp;
        if(temp->data==data)
        {
            return DUPLICATE;
        }
        else if(temp->data > data)
        {
            temp=temp->left;
        }
        else
        {
            temp=temp->right;
        }
    }
    if(parent->data > data)
    {
        parent->left=new;
    }
    else
    {
        parent->right=new;
    }
}