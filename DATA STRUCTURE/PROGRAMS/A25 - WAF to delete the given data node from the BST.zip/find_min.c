#include "tree.h"

int findmin(Tree_t * root)
{
    /* Check if root is empty */
    if(root==NULL)
        return FAILURE;
    while(root->left!=NULL) /* loop will run condition satisfy */
    {
        root=root->left;
    }
    return root->data;      /* return the root data */
}
