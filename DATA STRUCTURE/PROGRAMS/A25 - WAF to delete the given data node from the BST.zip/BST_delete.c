#include "tree.h"

extern int status;
/* Function to delete the node */
Tree_t * delete_BST(Tree_t * root, int data)
{
    /* Check if root is empty */
    if (root == NULL)
        return root;
    /* If the data to be deleted is less than root data */
    if (data < root->data)
        root->left = delete_BST(root->left, data);
    /* If the data to be deleted is greater than root data */
    else if (data > root->data)
        root->right = delete_BST(root->right, data);
    else
    {
        status = 1;    /* If data == root->data set status = 1 */
        /* If check leaf node or node with one child */
        if (root->left == NULL)
        {
            Tree_t *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            Tree_t *temp = root->left;
            free(root);
            return temp;
        }
        /* If check node with two children */
		int min = findmin(root->right);   /* smallest in the right subtree */
		root->data = min;
		/* Delete the inorder */
		root->right = delete_BST(root->right, min);
	}
	return root;
}