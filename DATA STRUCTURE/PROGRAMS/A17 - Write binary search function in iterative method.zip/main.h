#ifndef MAIN_H
#define MAIN_H

#include<stdio.h>
#include<stdlib.h>

#define DATA_NOT_FOUND -1
typedef int data_t;

data_t binarySearch_iterative(data_t *array, data_t size, data_t key);


#endif