#include "main.h"

/* Function for binary search using iterations */
data_t binarySearch_iterative(data_t *arr, data_t size, data_t key)
{
    /* declare the variables */
    int first=0, last=size, mid=0;
    /* loop run for binary search*/
    while(first < last)
    {
        mid=(first+last)/2;
        if(arr[mid] == key)
        {
            return mid;
        }
        else if(arr[mid] < key)
        {
            first= mid+1;
        }
        else
        {
            last=mid-1;
        }
    }
    return DATA_NOT_FOUND;
}
