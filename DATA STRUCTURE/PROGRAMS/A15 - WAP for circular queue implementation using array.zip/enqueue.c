#include "queue.h"

/* Function to Insert the element */
int enqueue(Queue_t *q, int data)
{
    /* Function call in if statement for Queue is full or not*/
    if(IsQueueFull(q) == SUCCESS)
    {
        return FAILURE;
    }
    
    /* front increment by 0 and pointing first index */
    if(q->front == -1)
    {
        (q->front)++;
    }
    
    /* In Circular queue updating index and data */
    q->rear =((q->rear)+1)% (q->capacity);
    q->Que[q->rear]=data;
    (q->count)++;           //increment the count value
    
    return SUCCESS;
}