#include "queue.h"

int IsQueueFull(Queue_t *q)
{
    /* count reaches to capacity then Queue is full */
    if(q->count == q->capacity)
        return SUCCESS;
    else
        return FAILURE; 
}

int IsQueueEmpty(Queue_t *q)
{
    /* count equal to 0 then Queue is empty */
    if(q->count == 0)
    {
        return SUCCESS;
    }
    return FAILURE;
}