#include "sll.h"

/* Function to reverse the given single linked list */
int reverse_iter(Slist **head) 
{ 
    if(*head == NULL)
    {
        return LIST_EMPTY;
    }
    
    /* declare and initilize variables */
    Slist *previous=NULL, *current=*head, *next=(*head)->link;
    
    /* only one node present */
    if((*head)->link == NULL)
    {
        return SUCCESS;
    }

    while(current != NULL)
    {
        current->link=previous;
        previous=current;
        current=next;
        
        if(next!=NULL)
        next=next->link;
    }
    
    /* Update head */
    *head=previous;
    
    return SUCCESS;
} 