#include "queue.h"

int dequeue(Queue_t **front, Queue_t **rear)
{
     /* Queue is empty */
    if(*front == NULL)
    {
		return FAILURE;
    }
    
    /* deleting node at first */
	*front=(*front)->link;
	
	/* free the node */
	free((*rear)->link);
	
	/* update rear of link */
	(*rear)->link=*front;
	
	
	return SUCCESS;
}