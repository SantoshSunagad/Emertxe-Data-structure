#include "dll.h"

int dl_insert_before(Dlist **head, Dlist **tail, int gdata, int ndata)
{
     // If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    /* Creating the new node */
    Dlist *new, *temp=*head;
    // Traverse the linked list to find the last node
    while(temp)
    {
        //data present or not in the list
        if(temp->data == gdata) 
        {
            new=malloc(sizeof(Dlist));  // Allocate memory for a new node
           
            if(new==NULL)               // Check if memory allocation is successfull
            {
                return FAILURE;     // Return FAILURE if memory allocation fails
            }
            
            /* Initialize the new node with the provided data */
            new->data=ndata;
            new->next=temp;
            new->prev=temp->prev;
            temp->prev=new;
            
            if(new->prev!=NULL)
            {
                new->prev->next=new;
            }
            else
                *head=new;      //update new to head 
        return SUCCESS;
        }
        temp=temp->next;            //Move to the next node
    }
    return DATA_NOT_FOUND;
}