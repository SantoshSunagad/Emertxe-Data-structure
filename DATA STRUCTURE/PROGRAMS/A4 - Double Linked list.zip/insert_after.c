#include "dll.h"

int dl_insert_after(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    // If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    /* Creating the new node */
    Dlist *new, *temp=*head;
    // Traverse the linked list to find the last node
    while(temp)
    {
         //data present or not in the list
        if(temp->data == gdata)
        {
            new=malloc(sizeof(Dlist));  // Allocate memory for a new node
           
            if(new==NULL)               // Check if memory allocation is successfull
            {
                return FAILURE;     // Return FAILURE if memory allocation fails
            }
            // Initialize the new node with the provided data
            new->data=ndata;
            new->prev=temp;
            new->next=temp->next;
            temp->next=new;
            
            if(new->next!=NULL)
            {
                new->next->prev=new;
            }
            else
                *tail=new;          //update new to tail
        return SUCCESS;
        }
        temp=temp->next;            //move to the next node
    }
    return DATA_NOT_FOUND;
}
