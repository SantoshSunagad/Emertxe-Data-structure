#include "dll.h"

int dl_delete_element(Dlist **head, Dlist **tail, int data)
{	
     // If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    Dlist *temp=*head;          //declare and update the temp
    
    // Traverse the linked list to find the last node
    while(temp!=NULL)
    {
          //data present or not in the list
        if((temp)->data==data)
        {   
            //data present at first node
            if(temp->prev==NULL)
            {
                *head=temp->next;
                (*head)->prev=NULL;
            }
            //data present at last node
            else if(temp->next==NULL)
            {
                *tail=temp->prev;
                (*tail)->next=NULL;
            }
            else
            {
                temp->prev->next=temp->next;
                temp->next->prev=temp->prev;
            }
            free(temp);                     //deallocating the memory
            return SUCCESS;
        }
        temp=(temp)->next;                  //move to next node        
    }
    return DATA_NOT_FOUND;              //Return if Data is not present
}
