#include "main.h"

/* Function to partition the array */
int partition(int *arr, int first, int last)
{
    /* declare the variables */
    int temp, pi=first, pivot=arr[last], i; 
    
    for(i=first;i<last;i++)
    {
        /* Each element value is lessthan pivot value or not */
        if(arr[i] < pivot)
        {
            /* Swapping */
            temp=arr[i];
            arr[i]=arr[pi];
            arr[pi]=temp;
            pi++;           //increment the pi
        }
    }
    /* Swapping, i is reaches to pivot */
     temp=arr[i];
     arr[i]=arr[pi];
     arr[pi]=temp;

     return pi;         //return pi index
}
