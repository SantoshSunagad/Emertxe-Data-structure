#include "main.h"

/* Function to search the element using binary search */
data_t binarySearch_recursive(data_t *arr, data_t size, data_t key, data_t first, data_t last)
{
    int m;  //declare the mid variable
    
   if(first<=last)
    {
        m=(first+last)/2;               //update the mid value
        if(arr[m] == key)
        {
            return m;                   //return position of key
        }
        else if(arr[m] < key)
        {
            return binarySearch_recursive(arr, size, key, (m+1), last); //Fuction call recursively
        }
        else
        {
            return binarySearch_recursive(arr, size, key, first, (m-1));    //Fuction call recursively
        }
    }
    return DATA_NOT_FOUND;      //return DATA NOT FOUND if key is not present
}
