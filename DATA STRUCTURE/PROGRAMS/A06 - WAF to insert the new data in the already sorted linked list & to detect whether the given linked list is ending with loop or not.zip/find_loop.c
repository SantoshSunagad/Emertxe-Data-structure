#include "sll.h"

/* Function for finding the loop in the link */
int find_loop(Slist *head)
{
    /* declare the 2 pointers */
    Slist *fast=head, *slow=head;
    
    /* List Empty or not */
    if(head == NULL)
    {
        return LIST_EMPTY;
    }
    
    /* loop run for finding the loop */
    while(fast)
    {
        slow=slow->link;
        fast=fast->link->link;
        if(fast==slow)
        {
            return SUCCESS;
        }
    }
    return LOOP_NOT_FOUND;
}