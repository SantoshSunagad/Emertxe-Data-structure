#include "sll.h"

/* Function for insert the number in sorted linked list */
int insert_sorted( Slist **head, data_t data) 
{ 
    Slist *temp=*head, *new=malloc(sizeof(Slist)), *previous=NULL;
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    if(*head == NULL || data < (*head)->data)
    {
        /* performig insert at first */
        new->link=*head;
        *head=new;
        return SUCCESS;
    }
    else
    {
        while(temp)
        {
            if(temp->data > data)
            {
                /* performig insert at before */
                new->link=previous->link;
                previous->link=new;
                return SUCCESS;
            }
            previous=temp;
            temp=temp->link;
        }
        /* performig insert at after */
        new->link=previous->link;
        previous->link=new;
        
        return SUCCESS;
    }

} 