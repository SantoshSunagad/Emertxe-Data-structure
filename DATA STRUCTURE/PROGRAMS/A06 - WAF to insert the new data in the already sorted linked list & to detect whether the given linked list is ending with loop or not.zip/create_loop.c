#include "sll.h"

/* Function to create the loop */
int create_loop(Slist **head, data_t data)
{
    /* check the loop empty or not */
    if(*head == NULL)
    {
        return LIST_EMPTY;
    }
    /* declare the 2 pointers */
    Slist *temp1=*head, *temp2=NULL;
    while(temp1->link != NULL)
    {
        if(temp1->data == data)
        {
            /* data matches then temp2 update as temp1 */
            temp2=temp1;
        }
        temp1=temp1->link;
    }
    
    if(temp2==NULL)
    {
        return DATA_NOT_FOUND;  // return data not found
    }
    else
    {
        temp1->link=temp2;      // creating the loop 
        return SUCCESS;
    }
}