#include "main.h"

int Postfix_Eval(char *Postfix_exp, Stack_t *stk)
{
	int i, operand1, operand2, result;
	i=0;

	// Condition to check the Postfix_exp array element is not null
	while( Postfix_exp[i] != '\0')
	{
		// Condition to check postfix array element is digit
		if ( isdigit(Postfix_exp[i]) )
		{
			push( stk, Postfix_exp[i]-48 );
			i++;
		}
		// if it is operator 
		else
		{
			operand2 = peek(stk);
			pop(stk);
			operand1 = peek(stk);
			pop(stk);

			switch (Postfix_exp[i])
			{
				case '+' :
					{
						result = operand1 + operand2;
						break;
					}
				case '-' :
					{
						result = operand1 - operand2;
						break;
					}
				case '*' :
					{
						result = operand1 * operand2;
						break;
					}
				case '/' :
					{
						result = operand1 / operand2;
						break;
					}

				case '%' :
					{
						result = operand1 % operand2;
						break;
					}
			}
			push( stk, result );
			i++;
		}
	}
	result = peek(stk);
	pop(stk);
	return result;
}