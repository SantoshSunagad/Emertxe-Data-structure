#include "main.h"

int Infix_Postfix_conversion(char *Infix_exp, char *Postfix_exp, Stack_t *stk)
{
	int i = 0, j = 0;

	// Condition to check the infix array element is not null
	while ( Infix_exp[i] != '\0')
	{
		// Condition to check if it  is a digit
		if ( '0' <= Infix_exp[i] && Infix_exp[i] <= '9' ) // we can use predefined isdigit() also
		{
			Postfix_exp[j] = Infix_exp[i];
			j++;
		}
		// Codition to check if it is a open bracket
		else if ( Infix_exp[i] == '(' )
		{
			push(stk, Infix_exp[i]);
		}
		// Condition to check if it is a closed bracket
		else if ( Infix_exp[i] == ')' )
		{
			while ( peek(stk) != '(' )
			{
				Postfix_exp[j] = peek(stk);
				j++;
				pop(stk);
			}
			pop(stk);
		}
		// else part if it is a operator
		else
		{
			// Condition to check if the stack is empty
			if ( stk -> top == -1 )
			{
				push(stk,Infix_exp[i]);
			}
			else
			{
				// condition to check the stack operator is greater than or equal or not
				if (priority(peek(stk)) >= priority(Infix_exp[i]))
				{
					Postfix_exp[j] = peek(stk);
					j++;
					pop(stk);
					push(stk, Infix_exp[i]);
				}
				else
				{
					push(stk, Infix_exp[i]);
				}
			}
		}
		i++;
	}
	// else part after all the elements in infix array are finished and collecting elements from stack and storing in postfix array
	while ( stk -> top != -1 )
	{
		Postfix_exp[j] = peek(stk);
		pop(stk);
		j++;
	}
	Postfix_exp[j] = '\0';
}