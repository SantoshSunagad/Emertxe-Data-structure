#include "sll.h"

int sl_sort(Slist **head)
{
    /* List Empty */
    if(*head == NULL)
    {
        return LIST_EMPTY;
    }
    //declare flag variable
    int flag;
    do
    {
        /* declare three pointers */
        Slist *current = *head, *next=(*head)->link, *prev=NULL;
        flag=0; //update flag
        /* Traverse */
        while(next)
        {
            /* According to condition for sorting */
            if(current->data > next->data)
            {
                flag=1;
                if(prev!=NULL)
                {
                   prev->link=next;
                }
                else
                {
                    *head=next;
                }
                current->link=next->link;
                next->link=current;
                
                prev=next;
                next=current->link;
            }
            else
            {
                prev=current;
                current=next;
                next=next->link;
            }
        }
    }while(flag>0);
    
    return SUCCESS;
}

