#include "sll.h"

int sl_delete_element(Slist **head, data_t data)
{
    // If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return FAILURE;
    }
    
    Slist *temp=*head, *previous=NULL;
    // Traverse the linked list to find the last node
    while(temp!=NULL)
    {
        if(temp->data==data)
        {
            //Delete beginning node in list
            if(previous==NULL)
               *head=temp->link;
            else
                previous->link=temp->link;      //
                
            free(temp);                     //clean the memory 
            return SUCCESS;
           
        }
        previous=temp;                  //before going next node the temp will assign to previous
        temp=temp->link;                //to move the next node
    }
    return DATA_NOT_FOUND;              //Return if Data is not present
}