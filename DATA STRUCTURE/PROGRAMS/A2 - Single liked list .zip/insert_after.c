#include "sll.h"

int sl_insert_after(Slist **head, data_t g_data, data_t ndata)
{
    // If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    /* Creating the new node */
    Slist *new, *temp=*head;
    // Traverse the linked list to find the last node
    while(temp)
    {
        if(temp->data == g_data)
        {
            new=malloc(sizeof(Slist));  // Allocate memory for a new node
           
            if(new==NULL)               // Check if memory allocation is successfull
            {
                return FAILURE;     // Return FAILURE if memory allocation fails
            }
            // Initialize the new node with the provided data
            new->data=ndata;
            new->link=temp->link;
            temp->link=new;
            return SUCCESS;
        }
        temp=temp->link;        //To move the temp next node
    }
    return DATA_NOT_FOUND;
}