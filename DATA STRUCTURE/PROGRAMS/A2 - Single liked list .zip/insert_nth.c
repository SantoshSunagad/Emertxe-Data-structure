#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, data_t n)
{
    //declare the variables
    Slist *temp=*head;
    data_t count=1;                     
    Slist *new=malloc(sizeof(Slist));      // Allocate memory for a new node
   
    if(new==NULL)                // Check if memory allocation is successful
        return FAILURE;         // Return FAILURE if memory allocation fails
    // Initialize the new node with the provided data
    new->data=data;
    new->link=NULL;
    //insert at the beginning node
    if (n == 1)
       return insert_at_first(head, data);
    else if(*head==NULL) // If the linked list is empty, make the new node the head and return
        return LIST_EMPTY;
   
    // Traverse the linked list to find the last node   
    while(temp!=NULL)
    {
        if(n ==  count+1)
        {
            new->link=temp->link;       // Initialize the new node with the provided data
            temp->link=new;
            return SUCCESS;
        }
        count++;
        temp=temp->link;                //To update the temp
    }
    return POSITION_NOT_FOUND;          //Return if position not found
}