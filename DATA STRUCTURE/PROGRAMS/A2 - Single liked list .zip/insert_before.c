#include "sll.h"

int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{
    /// If the linked list is empty, make the new node the head and return
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    Slist *new, *privious=NULL, *temp=*head;
    // Traverse the linked list to find the last node
    while(temp!=NULL)
    {
         if(temp->data == g_data)
        {
            new=malloc(sizeof(Slist));      // Allocate memory for a new node
            // Check if memory allocation is successfull
            if(new==NULL)
                return FAILURE;     // Return FAILURE if memory allocation fails
             
            new->data=ndata;        // Initialize the new node with the provided data
            new->link=temp;
            
            if(privious==NULL)
                *head=new;          //insert at beginning of the list
            else
                privious->link = new;
                
            return SUCCESS;
        }
        privious=temp;
        temp=temp->link;        //To move the temp to next node
    }
    return DATA_NOT_FOUND;
}