#include "main.h"

int Prefix_Eval(char *Prefix_exp, Stack_t *stk)
{
	int i, operand1, operand2, result;
	i=0;

	// Condition to check the Prefix_exp array element is not null
	while( Prefix_exp[i] != '\0')
	{
		// Condition to check Prefix array element is digit
		if ( isdigit(Prefix_exp[i]) )
		{
			push( stk, Prefix_exp[i]-48 );
			i++;
		}
		// if it is operator
		else
		{
			operand1 = peek(stk);
			pop(stk);
			operand2 = peek(stk);
			pop(stk);

			switch (Prefix_exp[i])
			{
				case '+' :
					{
						result = operand1 + operand2;
						break;
					}
				case '-' :
					{
						result = operand1 - operand2;
						break;
					}
				case '*' :
					{
						result = operand1 * operand2;
						break;
					}
				case '/' :
					{
						result = operand1 / operand2;
						break;
					}

				case '%' :
					{
						result = operand1 % operand2;
						break;
					}
			}
			push( stk, result );
			i++;
		}
	}
	result = peek(stk);
	pop(stk);
	return result;
}