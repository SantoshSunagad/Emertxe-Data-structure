/*
Name : Santosh Ramesh Sunagad 
Date : 02/01/2024
Description : Convert Infix to Prefix and evaluation Prefix expression
Input : 	2 * 3 – 3 + 8 / 4 / (1 + 1)
Output :  4
*/
#include "main.h"


void strrev(char *string)
{
    int i = 0, size, swap;

	// while loop to check the actual size of infix_array or number of elements present in infix_array
	while(string[i] != '\0')
	{
		i++;
		size = i;
	}
    
    /* TODO: Write logic for string reverse */
	for ( i=0; i<size/2; i++)
	{
		swap = string[i];
		string[i] = string[size-i-1];
		string[size-i-1] = swap;
	}
}
int main()
{
	char Infix_exp[50], Prefix_exp[50], ch;
	int choice, result;
	Stack_t stk;
	stk.top = -1;

	printf("Enter the Infix expression : ");
	scanf("%s", Infix_exp);

	strrev(Infix_exp);
	Infix_Prefix_conversion(Infix_exp, Prefix_exp, &stk);
	strrev(Prefix_exp);
	printf("PreFix expression : %s\n", Prefix_exp);

	stk.top = -1;

	strrev(Prefix_exp);
	result = Prefix_Eval(Prefix_exp, &stk);
	printf("\nResult : %d\n", result);
	return 0;
}
