#include "main.h"

data_t bubble(data_t *arr, int size )
{
    /* outer loop */
    for(int i=0;i<size-1;i++)
    {
        /* inner loop */
        for(int j=0;j<size-1-i;j++)
        {
            /* check condition for sorting array elements */
            if(arr[j]>arr[j+1])
            {
                /* Swapping */
                int temp =arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
}
