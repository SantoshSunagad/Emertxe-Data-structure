#include "main.h"

/* merge Function */
void merge(int *array, int first, int last, int mid)
{
    /* declare the variables and update the values */
   int n1=mid-first+2, n2=last-mid+1, i, j;
   int left[n1], right[n2];
   
   /* divide the array and assign to left array */
   for(i=0;i<n1-1;i++)
   {
       left[i]=array[first+i];
   }
   left[i]=100;
    /* divide the array and assign to right array */
   for(j=0;j<n2-1;j++)
   {
       right[j]=array[mid+j+1];
   }
   right[j]=100;
   
   i=j=0; //i and j assign to 0
   
   /* merging right and left array in sorting order */
   for(int k=first;k<=last;k++)
   {
       if(left[i] < right[j])
       {
           array[k]=left[i];
           i++;
       }
       else
       {
           array[k]=right[j];
           j++;
       }
   }
}
