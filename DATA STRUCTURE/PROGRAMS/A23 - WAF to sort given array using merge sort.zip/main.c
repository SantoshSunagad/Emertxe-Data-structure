/*
Name : Santosh Ramesh SUnagad
Date : 13/12/2023
Description : WAF to sort given array using merge sort
Sample input :  5 4 3 2 1
Sample output : 1 2 3 4 5
*/
#include "main.h"

/* Main Function */
int main()
{
	int i, size;

	/* Scanning the size */
	printf("Enter the size of an array\n");
	scanf("%d", &size);

	/* Declaring the array with size */
	int arr[size];

		
	printf("Enter the array elements\n");
	for (i = 0; i < size; i++)
	{
	    /* Scanning the array elements */
		scanf("%d", &arr[i]);
	}
	
	/* Calling the function to bubble sort */
	merge_sort(arr, 0, size-1);
	
	printf("Sorted array is : ");
	for (i = 0; i < size; i++)
	{
	    printf("%d ", arr[i]);
	}
		
	return 0;
}
