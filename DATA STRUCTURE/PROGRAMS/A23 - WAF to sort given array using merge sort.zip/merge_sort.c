#include "main.h"

/* merge_sort Function */
int merge_sort(int *array, int first, int last)
{
    if(first<last)
    {
        int mid=(first+last)/2;   
        /* Function call recursively */
        merge_sort(array, first, mid);  
        merge_sort(array, mid+1, last);
        /* inside function call merge function*/
        merge(array, first, last, mid);
    }
}
