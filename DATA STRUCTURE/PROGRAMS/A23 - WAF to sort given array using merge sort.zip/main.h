#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1


int merge_sort(int *array, int first, int last);
void merge(int *array, int first, int last, int mid);


#endif