#include "tree.h"
/* Function to creat the node */
Tree_t * creat_node (int data)
{
    /* Allocating the new node */
    Tree_t *new=(Tree_t *)malloc(sizeof(Tree_t));
    if(new==NULL)
    {
        return NULL;
    }
    /* Update the new node Address */
    new->data=data;
    new->left=NULL;
    new->right=NULL;
    return new;
}

/* Function to insert the data's in BST */
int insert_into_BST(Tree_t **root, int data)
{
    /* first node */
    if(*root == NULL)
    {
        *root=creat_node(data);
        return SUCCESS;
    }
    /* declare the two pointers */
    Tree_t *temp=*root, *pre=NULL;
    
    while(temp)
    {
        pre=temp;
        if(temp->data > data)
        {
            temp=temp->left;
        }
        else if(temp->data < data)
        {
            temp=temp->right;
        }
        else
        {
            return DUPLICATE;
        }
    }
    /* According to condition creat a node and update the link */
    if(pre->data < data)
        pre->right=creat_node(data);
    else 
        pre->left=creat_node(data);
        
    return SUCCESS;
}