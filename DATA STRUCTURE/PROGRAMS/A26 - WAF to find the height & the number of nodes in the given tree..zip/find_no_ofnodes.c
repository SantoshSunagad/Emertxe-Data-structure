#include "tree.h"
int count = 0;
int total_nodes(Tree_t *root)
{
    /* If the root is not equal to NULL */
	if (root != NULL)
	{
		/* Calling the function recursively  */
		total_nodes(root -> left);
		
        /* increase the count */
		count++;

		/* Calling the function recursively  */
		total_nodes(root -> right);
	}

	return count;
}
