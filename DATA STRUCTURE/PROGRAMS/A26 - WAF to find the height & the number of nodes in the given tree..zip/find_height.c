#include "tree.h"
int left_count=0, right_count=0;
int find_height(Tree_t *root)
{
    /* If the root is not equal to NULL */
    if (root != NULL)
	{
	    /* Function call recursively */
        left_count=find_height(root->left);
        right_count=find_height(root->right);
        
        if(left_count > right_count)
        {
            return left_count+1;
        }
        else
            return right_count+1;
	}
}
