#include "tree.h"

int findmin(Tree_t * root)
{
    if (root == NULL)
    {
        return FAILURE;
    }
    static int min=0;
    if(min==0)
    {
         min=root->data;
    }
    
   	if (root != NULL)
	{
		/* Calling the function recursively  */
		findmin(root -> left);

        /* find the minimum value */
		if(root->data < min)
		{
		    min=root->data;
		}
		
		/* Calling the function recursively  */
		findmin(root -> right);
	}
	return min;
}
