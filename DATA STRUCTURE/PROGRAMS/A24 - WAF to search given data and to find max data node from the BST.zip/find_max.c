#include "tree.h"

int findmax(Tree_t * root)
{
    if(root == NULL)
    {
        return FAILURE;
    }
    static int max=0;
   	if (root != NULL)
	{
		/* Calling the function recursively  */
		findmax(root -> left);

        /* find the maximum value */
		if(root->data > max)
		{
		    max=root->data;
		}
		
		/* Calling the function recursively  */
		findmax(root -> right);
	}
	return max;
}
