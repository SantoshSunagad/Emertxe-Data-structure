#include "tree.h"

/* Iteratively */
int search_BST(Tree_t * root, int data)
{
    if (root == NULL) 
    {
        return FAILURE; // Tree is empty
    }
    /* Traverse */
    while (root != NULL)
    {
        if (data == root->data) 
        {
            return SUCCESS; // Data found
        } 
        else if (data < root->data) 
        {
            root = root->left;
        } 
        else 
        {
            root = root->right;
        }
    }
	
    return NOELEMENT; // Data not found

}