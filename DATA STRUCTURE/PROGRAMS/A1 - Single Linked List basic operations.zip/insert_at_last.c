#include "sll.h"

int insert_at_last(Slist **head, data_t data)
{
    // Allocate memory for a new node
    Slist *new=malloc(sizeof(Slist));
    // Check if memory allocation is successful
    if (new==NULL)
    {
        return FAILURE; // Return FAILURE if memory allocation fails
    }
    // Initialize the new node with the provided data
    new->data=data;
    new->link=NULL;
    // If the linked list is empty, make the new node the head and return
    if(*head == NULL){
        *head=new;
        return SUCCESS;
    }
    Slist *temp=*head;
    // Traverse the linked list to find the last node
    while(temp->link)
    {
        temp=temp->link;
    }
    // Attach the new node to the last node's link
    temp->link=new;
    return SUCCESS;
}