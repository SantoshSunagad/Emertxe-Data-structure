#include "sll.h"

int sl_delete_last(Slist **head)
{
    // Check if the list is empty
    if(*head==NULL)
    {
        return FAILURE; // Return failure if the list is empty
    }
     Slist *temp=*head, *previous;
    //if only one node present 
    if(temp->link==NULL)
    {
         *head=NULL;            //update head to NULL 
         free(temp);            //Free the memory
         return SUCCESS;        
    }
    // Traverse the list to find the last node and store previous node 
    while(temp->link!=NULL)
    {
        previous=temp;
        temp=temp->link;
    }
    previous->link=NULL;    // Set the previous link to NULL
    free(temp);              // Free the memory of the last node
    return SUCCESS;         // Return success after deletion
}