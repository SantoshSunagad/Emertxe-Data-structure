#include "sll.h"

int sl_delete_first(Slist **head)
{
    // Check if the list is empty
    if(*head==NULL)
    {
        return FAILURE; // Return failure if the list is empty
    }
    Slist *temp=*head;  // Create a temporary pointer and update head pointer
    *head=temp->link;   // Update the head to point to the next node
    free(temp);         // Free the memory of the first node
    return SUCCESS;     // Return success after deletion

}