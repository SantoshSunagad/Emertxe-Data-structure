#include "sll.h"

int find_node(Slist *head, data_t data)
{
    int count=1;     // Initialize a count by 1
    Slist *temp = head;     // Create a temporary pointer to traverse the list
    // Check if the list is empty
    if(head == NULL)
	{
	    return FAILURE;     // Return failure if the list is empty
	}
    while(temp)
    {
        if(temp->data==data)
        {
            return count;       // Return the position if the data is found
        }
        count++;                // Increment the counter for the current position
        temp=temp->link;        // Move to the next node in the list
    }
    return FAILURE;     // Return failure if the data is not found in the list

}
