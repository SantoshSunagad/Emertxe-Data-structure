#include "sll.h"

int sl_delete_list(Slist **head)
{
	Slist *temp=*head;      // Create a temporary pointer to traverse the list
    // Check if the list is empty
	if(*head == NULL)
	{
	    return FAILURE;  // Return failure if the list is empty
	}
    // Traverse the list till the last node
	while(temp!=NULL)
	{
	    *head=temp->link;   // Update the head to the next node
	    free(temp);         // Free the memory of the current node
	    temp=*head;         // Free the memory of the current node
	}
      
	return SUCCESS;     // Return success after deleting the entire list
}