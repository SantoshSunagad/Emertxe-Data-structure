#include "sll.h"

int insert_at_first(Slist **head, data_t data)
{
    // Allocate memory for a new node
	Slist *new=malloc(sizeof(Slist));
    // Check if memory allocation is successful
    if (new==NULL)
    {
        return FAILURE; //// Return FAILURE if memory allocation fails
    }
    // Initialize the new node with the provided data
    new->data=data;
    // Set the new node link to the current head of the linked list
    new->link=*head;
    // Update the head to point to the new node, making it the new head
    *head=new;
    return SUCCESS; // Return SUCCESS as the new node is successfully inserted at the beginning
    
}