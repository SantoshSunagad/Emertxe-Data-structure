#include "sll.h"

void print_list(Slist *head)
{
     // Check if the list is empty
	if (head == NULL)
	{
		printf("INFO : List is empty\n");       //print this message
	}
    else
    {
	    while (head)		
	    {
		    printf("%d -> ", head -> data);     //print data till end of node
		    head = head -> link;            //Move to next node
	    }

	    printf("NULL\n");   //print NULL last
    }
}