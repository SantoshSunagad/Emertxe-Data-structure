#include "sll.h"

void print_list(Slist *head)
{
    // Check if the list is empty
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
    else
    {
        /* Traverse till the last node and print the values */
	    while (head)		
	    {
		    printf("%d -> ", head -> data);
		    head = head -> link;
	    }

	    printf("NULL\n");
    }
}