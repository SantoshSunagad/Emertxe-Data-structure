#include "sll.h"

//remove duplicate data's from list
int remove_duplicates( Slist **head )
{
    // Check if the list is empty
    if(*head == NULL)
    {
        return FAILURE;
    }
    
     /* Check if the list has only one element (no duplicates to remove) */
    if((*head)->link == NULL)
    {
        return SUCCESS;
    }
    
    // Initialize pointers for traversal
    Slist *temp1=*head, *temp2, *previous=*head;
    
    // Traverse the list
    while(temp1!=NULL)
    {
        temp2=temp1->link;
        previous=temp1;
        // Inner loop to compare and remove duplicates
        while(temp2!=NULL)
        {
            if(temp1->data == temp2->data)
            {
                // Remove duplicate node
                previous->link=temp2->link;
                free(temp2);
                temp2=previous;             // Reset temp2 to the previous node
            }
            previous=temp2;                 //before move to next node temp2 will in previous
            temp2=temp2->link;              //move to the next node(temp2, inner loop)
        }
        temp1=temp1->link;          //move to next node(temp1, outer loop)
    }
    return SUCCESS;         
}