#include"hash.h"

int search_HT(hash_t *arr, int data, int size)
{
    int key =data%size;
    if(arr[key].value == data)
    {
        return SUCCESS;
    }
    hash_t *temp=arr[key].link;
    
    while(temp)
    {
        if(temp->value == data)
        {
            return SUCCESS;
        }
        temp=temp->link;
    }
    return DATA_NOT_FOUND;
}