#include"hash.h"

int delete_element(hash_t *arr, int data, int size)
{
    // expression for finding index value
	int index = data % size;
	
    // Assinging link address to hash_t pointers
	hash_t *current = arr[index].link;
	hash_t *previous=NULL;
	
    // condition to check if the index value is already empty
	if (arr[index].value == -1)
	{
		return DATA_NOT_FOUND;
	}
	else if (arr[index].value == data && arr[index].link == NULL)
	{
		arr[index].value = -1;
		return SUCCESS;
	}
	// condition to check if the index value has some data and link is null indicates there are no nodes linked
	else if (arr[index].value == data && arr[index].link != NULL)
	{
		arr[index].value = current -> value;
		arr[index].link = current -> link;
		free(current);
		return SUCCESS;
	}
	// condition to check if the index value has data
	else if (current -> value == data)
	{
		arr[index].link = current -> link;
		free(current);
		return SUCCESS;
	}
	else
	{
	    //while loop to travarse through the link till last node to find the data
		while (current != NULL)
		{
			if (current -> value == data)
			{
				if (current -> link == NULL)
				{
					previous -> link = NULL;
				}
				else
				{
					previous -> link = current -> link;
				}
				free(current);
				return SUCCESS;
			}
			else 
			{
				previous = current;
				current = current -> link;
			}
		}
	}

	return DATA_NOT_FOUND;

}