#include "stack.h"

int Peek(Stack_t **top)
{
    /* To get top of the element*/
    return (*top==NULL)? FAILURE : ((*top)->data);
}