#include "stack.h"

int Push(Stack_t **top, data_t data)
{
    /* Allocating new memory */
    Stack_t *new=malloc(sizeof(Stack_t));
    
    /* check memory allocated or not */
    if(new==NULL)
    {
        return FAILURE; 
    }
    /*insert data+link to new node*/
    new->data=data;
    new->link=*top;
    
    //update top to new
    *top=new;
    
    return SUCCESS;
}
 