#include "stack.h"

int Pop(Stack_t **top)
{
    /* Return failure if the list is empty */
    if(*top==NULL)
    {
        return FAILURE; 
    }
    
    Stack_t *temp=*top;  // Create a temporary pointer and update head pointer
    
    *top=temp->link;   // Update the head to point to the next node
    
    free(temp);         // Free the memory of the first node
    
    return SUCCESS;	

}