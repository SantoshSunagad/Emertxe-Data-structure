#ifndef MAIN_H
#define MAIN_H

#include<stdio.h>
#include<stdlib.h>

void build_maxheap(int *heap, int size);
int heap_sort(int *heap, int );
void max_heap(int *heap, int , int );

#endif