#include "main.h"

/* Function to sort the array using heap sort */
int heap_sort(int *heap, int size )
{
    /* loop run for heap sorting */
    for(int i=size-1;i>=0;i--)
    {
        /* swapping */
        int temp = heap[0];
        heap[0] = heap[i];
        heap[i] = temp;
        
        max_heap(heap, 0, i);   //function call
    }
}       
