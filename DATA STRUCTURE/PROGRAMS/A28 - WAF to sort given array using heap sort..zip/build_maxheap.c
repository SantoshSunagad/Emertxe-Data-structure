#include "main.h"

void build_maxheap(int *heap, int size)
{
    /* To build max heap */
    for(int  i = (size/2)-1;i>=0;i--)
    {
        /* Function call */
        max_heap(heap, i, size);
    }
}