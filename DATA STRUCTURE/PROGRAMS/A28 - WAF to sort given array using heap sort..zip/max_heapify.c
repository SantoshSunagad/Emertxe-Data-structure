#include "main.h"

/* Function to check the number is minimum or maximum to decide the position */
void max_heap(int *heap, int i, int size)
{
    /* declare variables and initilize */
    int max=i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    /* According to condition update the max vale */
    if(left < size && heap[left] > heap[max])
    {
        max=left;
    }
    if(right < size && heap[right] > heap[max])
    {
        max=right;
    }
    
    if(i != max)
    {
        /* swapping */
        int temp=heap[i];
        heap[i]=heap[max];
        heap[max]=temp;
        
        max_heap(heap, max, size);  //function call recursively
    }
}
