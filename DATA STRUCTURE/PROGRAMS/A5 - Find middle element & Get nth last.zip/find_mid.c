#include "sll.h"
/* Function to get the middle of the linked list*/
int find_mid(Slist *head, int *mid) 
{
    // Check if the list is empty
    if(head==NULL)
    {
        return LIST_EMPTY;
    }
    
     // Initialize pointers for fast and slow traversal
    Slist *fast=head, *slow=head;
    
    // Traverse the list with two pointers (fast and slow)
    while(fast != NULL && fast->link != NULL)
    {
        fast=fast->link->link;          // Move fast pointer two steps
        slow=slow->link;                // Move slow pointer one step
    }
    
    *mid=slow->data;                    // Set the middle value to the data of the slow pointer
    
    return SUCCESS;
} 