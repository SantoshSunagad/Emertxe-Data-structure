#include "sll.h"

int sorted_merge( Slist **head1, Slist **head2)
{
    /* check Both list empty */
    if(*head1 == NULL && *head2 == NULL)
    {
        return FAILURE;
    }
        /* head2 will NULL or not*/
    else if(*head1 != NULL && *head2 ==NULL)
    {
        return sort(head1); //Function call
    }
        /* head1 will NULL or not*/
    else if(*head1 == NULL && *head2 != NULL)
    {
        *head1=*head2;
        return sort(head1);  //Function call
    }
    /* if both List are not equal NULL*/
    
    Slist *temp = *head1; //declare temp initialize with head1
    /* Traverse */
    while(temp)
    {
        /* Traverse till last node*/
        if(temp->link == NULL)
        {
            temp->link=*head2;      //merge both list into one list 
            return sort(head1);     //Function call
        }
        temp=temp->link;        //move to next node
    }
}