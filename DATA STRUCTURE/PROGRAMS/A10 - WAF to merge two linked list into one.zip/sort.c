#include "sll.h"    

//sortList() will sort nodes of the list in ascending order  
int sort(Slist **head) 
{  
    /* checking the list empty or only one node present */
    if(*head == NULL || (*head)->link == NULL)
    {
        return SUCCESS;
    }
    /* declare the variables */
    Slist *temp1=*head, *temp2=*head;
        //Outer loop
        while(temp1)
        {
            //Inner loop
            while(temp2)
            {
                /* condition for sorting the data */
                if(temp1->data < temp2->data)
                {
                    /* swapping */
                    int temp=temp1->data;
                    temp1->data=temp2->data;
                    temp2->data=temp;
                }
                temp2=temp2->link;  //move to next node
            }
            temp2=*head;    //reinitialized temp2 has head
            temp1=temp1->link;      //move to next node
        }
    return SUCCESS;
}
