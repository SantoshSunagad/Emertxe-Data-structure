#include "stack.h"

/* Function for Poping the element */
int Pop(Stack_t *s)
{	
    // Check if the stack is empty
    if ((s->top == -1))
        return FAILURE; // Return failure if the stack is empty

     // Retrieve the value from the top of the stack
	int value=s->stack[s->top];
	
	// Decrement the top index to remove the top element
	(s->top)--; 
		
	return SUCCESS;     // Return success after popping the element
}