#include "stack.h"

/* Function for display the top of the element in Stack */
int Peek(Stack_t *s)
{
    /* Return the value at the top of the stack without removing it */ 
    return (s->top == -1)? FAILURE :  (s->stack[s->top]); 
}