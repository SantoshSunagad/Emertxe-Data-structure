#include "stack.h"

/* Fuction for inserting the element */
int Push(Stack_t *s, int element)
{
    // Check if the stack is already full 
	if((s->top == (s->capacity)-1))
	{
	    return FAILURE;         // Return failure if the stack is full
	}
	
	 // Increment the top index and insert the element into the stack
	(s->top)++;
	s->stack[s->top]=element;
	
	return SUCCESS;         // Return success after the insertion
}