#include "main.h"

data_t insertion(data_t *arr, data_t size)
{
    /* Outer loop */ 
    for(int i=1;i<size;i++)
    {
        /*declare the variables*/
        int key=arr[i];
        int j=i-1;
        /*inner loop*/
        while(j >= 0 && arr[j] > key)
        {
            arr[j+1]=arr[j];    //swap the element
            j--;                //decrement j value
        }
        arr[j+1]=key;           //insert element in sorted position
    }
}
