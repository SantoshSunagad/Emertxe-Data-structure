#include "dll.h"

int dl_delete_list(Dlist **head, Dlist **tail)
{
    // Check if the list is initially empty
    if(*head==NULL)
    {
        return FAILURE;
    }
    
    // Loop through the list until the head becomes NULL (end of the list)
    while(*head)
    {
        // Check if there is only one node in the list
        if(*head==*tail)
        {
            free(*head);
            *head=NULL;
            *tail=NULL;
            return SUCCESS;
        }
        else
        {
            (*head)=(*head)->next;
            free((*head)->prev);
            (*head)->prev=NULL;
        }
    }
    return SUCCESS;
}