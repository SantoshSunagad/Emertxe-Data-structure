#include "dll.h"

int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    /* Allocate memory for a new nod */
    Dlist *new=malloc(sizeof(Dlist));
    
    // Check if memory allocation was successful
    if(new==NULL)
    {
        return FAILURE;
    }
    
    new->data=data;         // Set the data of the new node
    // Set the previous and next pointers of the new node
    new->prev=NULL;
    new->next=*head;
    // Check if the list is initially empty
    if(*head==NULL)
    {
         // If empty, set both head and tail to the new node
        *head=new;      
        *tail=new;
        return SUCCESS;
    }
    /*update the new node to head */
    (*head)->prev=new;
    *head=new;
    return SUCCESS;
}