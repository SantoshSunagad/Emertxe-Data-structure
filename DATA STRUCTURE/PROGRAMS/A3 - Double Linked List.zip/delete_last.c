#include "dll.h"

int dl_delete_last(Dlist **head, Dlist **tail)
{
    // Check if the list is initially empty
    if(*head==NULL)
    {
        return FAILURE;
    }
    
    // Check if there is only one node in the list
    if(*head==*tail)
    {
        free(*head);                // Free the memory allocated for the single node
        // Set both head and tail to NULL, indicating an empty list
        *head=NULL;
        *tail=NULL;
        return SUCCESS;
    }
    
    *tail=(*tail)->prev;        // Move the tail pointer to the previous node
    free((*tail)->next);        // Free the memory allocated for the last node
    (*tail)->next=NULL;         // Set the next pointer of the new last node to NULL
    return SUCCESS;
}