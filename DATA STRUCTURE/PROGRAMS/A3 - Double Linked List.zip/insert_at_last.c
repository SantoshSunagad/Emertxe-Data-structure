#include "dll.h"

int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
    /* Allocate memory for a new nod */
    Dlist *new=malloc(sizeof(Dlist));
    
     // Check if memory allocation was successful
    if(new==NULL)
    {
        return FAILURE;
    }
    
    /* Update the new node data+link*/
    new->data=data;
    new->next=NULL;
    new->prev=*tail;
    
    // Check if the list is initially empty
    if(*head==NULL)
    {
        return dl_insert_first(head, tail, data);       //call the function insert at first
    }
    /*Update the new node link in to the last node*/
    (*tail)->next=new;
    *tail=new;
    return SUCCESS;
}