#include "dll.h"

int dl_delete_first(Dlist **head, Dlist **tail)
{
     // Check if the list is initially empty
    if(*head==NULL)
    {
        return FAILURE;
    }
    
    // Check if there is only one node in the list
    if(*head==*tail)
    {
        free(*head);            // Free the memory allocated for the single node
        // Set both head and tail to NULL, indicating an empty list
        *head=NULL;
        *tail=NULL;
        return SUCCESS;
    }
    *head=(*head)->next;        // Move the head pointer to the next node
    free((*head)->prev);        // Free the memory allocated for the first node
    (*head)->prev=NULL;          // Set the head previous pointer to NULL
    return SUCCESS;
}