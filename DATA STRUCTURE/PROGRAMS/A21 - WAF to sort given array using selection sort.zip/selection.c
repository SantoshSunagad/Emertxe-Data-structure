#include "main.h"

data_t selection(data_t *arr, data_t size )
{
    /* declare the variables */
    int current_min, current_item, temp;
    /* Outer loop*/
    for(int i=0;i<size-1;i++)
    {
        current_min=i;  //update current_min equal to i
        /* inner loop */
        for(current_item=current_min+1;current_item<size;current_item++)
        {
            /* check the condition for sorting */ 
            if(arr[current_min] > arr[current_item])
            {
                current_min=current_item;
            }
        }
        if(current_min != i)
        {
            /* Swapping */
            temp = arr[current_min];
            arr[current_min]=arr[i];
            arr[i]=temp;
        }
    }
}