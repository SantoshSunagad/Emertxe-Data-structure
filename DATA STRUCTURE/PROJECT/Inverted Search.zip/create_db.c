#include "main.h"
/* Create Database Function Definition */
status create_db(f_list *head, create_database *hash)
{
    f_list *temp = head;
    char str[30];
    int key;

    while (temp != NULL)
    {
        FILE *fptr = fopen(temp->f_name, "r");
        while (fscanf(fptr, "%s", str) != EOF)
        {
            key = tolower(str[0]) % 97;
            if (key < 0 || key > 25)
                key = 26;
            /*link == Null*/
            if (hash[key].m_link == NULL)
            {
                /*Function call create main and sub node */
                hash[key].m_link = main_sub_nodecreate(str, temp);
            }
            /*link != NULL*/
            else
            {
                int flag = 0;
                m_node *temp1 = hash[key].m_link, *prev = NULL;
                while (temp1 != NULL)
                {
                    if (strcmp(temp1->word, str) == 0)
                    {
                        flag = 1;
                        s_node *s_temp = temp1->m_sub_link, *st_prev = NULL;
                        while (s_temp != NULL)
                        {
                            if (strcmp(s_temp->file_name, temp->f_name) == 0)
                            {
                                ++(s_temp->word_count);
                                break;
                            }
                            st_prev = s_temp;
                            s_temp = s_temp->s_sub_link;
                        }

                        /*create sub node and update*/
                        if (s_temp == NULL)
                        {
                            s_node *s_new = malloc(sizeof(s_node));
                            s_new->word_count = 1;
                            strcpy(s_new->file_name, temp->f_name);
                            s_new->s_sub_link = NULL;
                            ++(temp1->file_count);
                            st_prev->s_sub_link = s_new;
                        }
                    }
                    prev = temp1;
                    temp1 = temp1->m_main_link;
                }
                /*Word not found then crete main and sub node */
                if (flag == 0)
                {
                    prev->m_main_link = main_sub_nodecreate(str, temp);
                }
            }
        }
        fclose(fptr);
        temp = temp->link;
    }
    return e_success;
}
