#include "main.h"
extern int C_database, update;
/* Function Definition to display the contents */
status Display(create_database *hash, f_list *head)
{
    /* Empty Database */
    if (C_database == 0 && update == 0)
    {
        return LIST_EMPTY;
    }

    printf("\n-----------------------------------------------------------------------------\n");
    printf("[%-5s] [%-5s] %-5s  %-6s   %-15s\n", "Index", "word", "file_count", "word_count", "[File/s : File: File name]");
    printf("-----------------------------------------------------------------------------\n");
    for (int i = 0; i < 27; i++)
    {
        m_node *temp2 = hash[i].m_link;
        while (temp2 != NULL)
        {

            printf("[%6d] %-10s %-15d", i, temp2->word, temp2->file_count);
            s_node *s_temp = temp2->m_sub_link;
            while (s_temp != NULL)
            {
                printf("%-10d %-10s", s_temp->word_count, s_temp->file_name);
                    printf("\n %-36s","\n");
                s_temp = s_temp->s_sub_link;
            }
            printf("\n");
            temp2 = temp2->m_main_link;
        }
    }
    return e_success;
}
