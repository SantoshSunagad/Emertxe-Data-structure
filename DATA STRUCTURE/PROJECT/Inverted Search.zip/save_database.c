#include "main.h"
/* Function Definition For Save the Database */
status save_database(create_database *hash, char str[])
{
    /*declare file pointer and open the file */
    FILE *fptr = fopen(str, "w");
    if (fptr == NULL)
        return e_failure;

    for (int key = 0; key < 27; key++)
    {
        /*Take main node temp*/
        m_node *m_temp = hash[key].m_link;
        if (m_temp == NULL)
            continue;

        fprintf(fptr, "%s:", "#");
        fprintf(fptr, "%d\n", key);
        while (m_temp != NULL)
        {

            fprintf(fptr, "%s:", m_temp->word);
            fprintf(fptr, "%d:", m_temp->file_count);

            /* Taking sub node temporary */
            s_node *s_temp = m_temp->m_sub_link;
            while (s_temp)
            {
                fprintf(fptr, "%s:", s_temp->file_name);
                fprintf(fptr, "%d:", s_temp->word_count);
                s_temp = s_temp->s_sub_link;
            }
            fprintf(fptr, "%s\n", "#");
            m_temp = m_temp->m_main_link;
        }
    }
    fclose(fptr);
    return e_success;
}