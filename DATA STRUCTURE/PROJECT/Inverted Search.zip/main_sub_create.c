#include "main.h"
/* Function Definition for main and sub node creation */
m_node *main_sub_nodecreate(char str[], f_list *temp)
{
    /* Main node creation and updation */
    m_node *m_new = malloc(sizeof(m_node));
    if (m_new == NULL)
    {
        printf("INFO: m_node creation failure\n");
        exit(0);
    }

    /* Sub node creation and update */
    s_node *s_new = malloc(sizeof(s_node));
    if (s_new == NULL)
    {
        printf("INFO: s_node creation failure\n");
        exit(0);
    }
    /* Both nodes Updating */
    m_new->file_count = 1;
    strcpy(m_new->word, str);
    m_new->m_sub_link = s_new;
    m_new->m_main_link = NULL;

    s_new->word_count = 1;
    strcpy(s_new->file_name, temp->f_name);
    s_new->s_sub_link = NULL;

    return m_new;
}