#include "main.h"
/* Declare global variable */
int flag = 0;
/* Function Definition for read and validate */
status read_and_validate(int argc, char *argv[], f_list **head)
{
	for (int i = 1; i < argc; i++)
	{
		/* Function call for file exist or not */
		if (open_files(argv[i]) == e_success)
		{
			/* If Exist then Store in Single linked list */
			f_list *new = malloc(sizeof(f_list));
			if (new == NULL)
			{
				return e_failure;
			}

			if (*head == NULL)
			{
				*head = new;
				strcpy(new->f_name, argv[i]);
				new->link = NULL;
			}
			else
			{
				f_list *temp = *head;
				f_list *prev = NULL;
				while (temp != NULL)
				{
					if (strcmp(temp->f_name, argv[i]) == 0)
					{
						printf("%s file is duplicate\n", argv[i]);
						flag = 1;
						break;
					}
					prev = temp;
					temp = temp->link;
				}
				if (flag == 0)
				{
					strcpy(new->f_name, argv[i]);
					prev->link = new;
					new->link = NULL;
				}
				flag = 0;
			}
		}
		else
		{
			return e_failure;
		}
	}
	printf("************************ Open File Successful ************************\n");
	return e_success;
}
/* Function Definition for Open file function */
status open_files(char *argv)
{
	/* Declare File pointer and open file in Read mode*/
	FILE *fptr = fopen(argv, "r");
	if (fptr != NULL)
	{
		/*Check File is Text file or not */
		if (strcmp((strstr(argv, ".")), ".txt") == 0)
		{
			fseek(fptr, 0, SEEK_END);
			if (ftell(fptr) != 0)
			{
				fclose(fptr);
				return e_success;
			}
			else
			{
				printf("Error :file is empty %s\n", argv);
				return e_failure;
			}
		}
		else
		{
			printf("Error : file does not have .txt extension %s\n", argv);
			return e_failure;
		}
	}
	else
	{
		printf("Error : file does not exist %s\n", argv);
		return e_failure;
	}
}
/* Function Definition for backup the data files */
int backup_file_list(SSl **head2, create_database *hash)
{
    int flag=0;
	for (int i = 0; i < 27; i++)
	{
        m_node *mtemp=hash[i].m_link;
        while (mtemp!=NULL)
        {
        
		s_node *s_temp=mtemp->m_sub_link;
		while (s_temp)
		{
			SSl *new = malloc(sizeof(SSl));
			if (new == NULL)
			{
				return e_failure;
			}

			if (*head2 == NULL)
			{
				*head2 = new;
				strcpy(new->f_name, s_temp->file_name);
				new->link = NULL;
			}
			else
			{
				SSl *temp = *head2;
				SSl *prev = NULL;
				while (temp != NULL)
				{
					if (strcmp(temp->f_name, s_temp->file_name) == 0)
					{
						flag = 1;
						break;
					}
					prev = temp;
					temp = temp->link;
				}
				if (flag == 0)
				{
					strcpy(new->f_name, s_temp->file_name);
					prev->link = new;
					new->link = NULL;
				}
				flag = 0;
			}
			s_temp=s_temp->s_sub_link;
        }
        mtemp=mtemp->m_main_link;

		}
	}
	return e_success;
}
/* Function Definition for Remove the Duplicate's (only when update database)*/
status validate_files(SSl **head2, f_list **head)
{
    f_list *temp1 = *head, *pre = NULL;
    SSl *temp2 = *head2;
   
    while (temp2)
    {
        temp1=*head;
        while (temp1)
        {
            
            if (strcmp(temp2->f_name, temp1->f_name) == 0)
            {
                f_list *t = temp1->link;
                if (temp1 == *head)
                {
                    *head = temp1->link;
                }
                else
                {
                    pre->link = temp1->link;
                }
                free(temp1);
                temp1 = t;
                continue;
            }
            pre = temp1;
            temp1 = temp1->link;
        }
        temp2 = temp2->link;
    }
    
    if (*head == NULL)
    {
        return e_alerady;
    }
    else
    return e_success;
}
