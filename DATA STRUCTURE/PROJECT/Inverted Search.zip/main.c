/*
Name : Santosh Ramesh Sunagad
Date : 07/01/2024
Project : Inverted Search
		Description - The purpose of storing an index is to optimize speed and performance 
					  in finding relevant documents for a search query. Without an index, 
					  the search engine would scan every document in the corpus, which would 
				      require considerable time and computing power.
Pre-requisite: 	> Hashing
				> Single linked list
Cases : 1.Create Database 
		2.Display Database
		3.Upadate Database
		4.Search
		5.Save Database
*/

#include "main.h"
/* Declare global variables */
int C_database = 0, update = 0;

/* Main Function */
int main(int argc, char *argv[])
{
	/* Declare the variables */ 
	int option,ret; 
	char choice, str[30];
	f_list *head = NULL, *temp=NULL;
	SSl *head2 = NULL;
	create_database hash[27];

	/*Updating intial values to hash table*/
	for (int i = 0; i < 27; i++)
	{
		hash[i].key = i;
		hash[i].m_link = NULL;
	}
	printf("---------------------------------------------------------------------------------------------\n");
	/* To check Command line argument is passed or not*/
	if (argc <= 1) 
	{
		printf("Error : Insufficient Arguements\nUsage : ./a.out file1.txt file2.txt\n");
		exit(0);
	}
	else
	{
		/* To store the Command line argument and remove repeated Filenames */
		if (read_and_validate(argc, argv, &head) == e_success)
			printf("********************Read and Validate is Completed********************\n");
		else
		{
			printf("Error : Read and Validate\n");
			return 0;
		}
	}
	printf("---------------------------------------------------------------------------------------------\n");
	/*Menu Table for User to Choice Options*/
	do
	{
		fflush(stdout);
		printf("\nSlect your choice among following options:\n1.Create Database\n2.Display Database\n3.Upadate Database\n4.Search\n5.Save Database\nEnter your choice: ");
		scanf(" %d", &option);
		printf("\n-----------------------------------------------------------------------------\n");
		switch (option)
		{
		case 1:	/* Create Database */
			ret=validate_files(&head2, &head);
			if (ret != e_alerady && C_database == 0)
			{
				if (create_db(head, hash) == e_success)
				{
					C_database = 1;
					temp=head;
					printf("Successful : Creation of DATABASE for file : ");
					while (temp)
					{
						printf("%s ", temp->f_name);
						temp=temp->link;
					}
					printf("\n");
				}
				else
					printf("Failure : Creation of DATABASE for file\n");
			}
			else
				printf("INFO : Alreday created data base\n");
			break;
		case 2:	/* Display Database */
			if (ret = Display(hash, head) == LIST_EMPTY)
			{
				printf("INFO : LIST EMPTY\n");
			}
			break;
		case 3:	/* Upadte Database */
			if (update == 0 && C_database == 0)
			{
				ret = update_dabase(hash, &head);
				backup_file_list(&head2, hash);

				update = 1;
				if (ret == e_success)
				{
					printf("INFO : Upadate SUCCESS\n");
				}
				else
					printf("INFO : Update FAILURE\n");
			}
			else
				printf("INFO : Alerday Database updates\n");
			break;
		case 4:	/* Search in Database */
			printf("Enter the word you want search: ");
			scanf("%s", str);
			if (ret = search(str, hash, head) == DATA_NOT_FOUND)
			{
				printf("INFO : DATA NOT FOUND\n");
			}
			else if (ret == LIST_EMPTY)
			{
				printf("INFO : LIST EMPTY\n");
			}
			else
				printf("INFO : SUCCESS\n");
			break;
		case 5:	/* Save Database */
			printf("Enter file name : ");
			scanf("%s", str);

			if (save_database(hash, str) == e_success)
				printf("INFO: Database is saved\n");
			else
				printf("INFO: Database saving Failure\n");
			break;
		default:
			printf("Invalid Choice!\n");
			break;
		}
		printf("-----------------------------------------------------------------------------\n");
		printf("\nDo you want to continue ?\nEnter y/Y to continue and n/N to discontinue: ");
		scanf(" %c", &choice);
	} while (choice == 'y' || choice == 'Y');

	return 0;
}
