#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>

#define LIST_EMPTY -1
#define DATA_NOT_FOUND -2

/* Enum's */
typedef enum
{
    e_success,
    e_failure,
    e_alerady 
} status;

/* Subnode Structures */
typedef struct subnode
{
    int word_count;
    char file_name[30];
    struct subnode *s_sub_link;
} s_node;

/* Main node Structures*/
typedef struct mainnode
{
    int file_count;
    char word[30];
    struct mainnode *m_main_link;
    s_node *m_sub_link;
} m_node;

/* Command line arguments (file names) are stroe in list */
typedef struct filenode
{
    char f_name[30];
    struct filenode *link;
} f_list;

/* For backuping the file through the backup file's are stroe in list */
typedef struct retrive
{
    char f_name[30];
    struct retrive *link;
}SSl;


/* Create Database Structures */
typedef struct create_db
{
    int key;
    m_node *m_link;
} create_database;

/* Function Prototypes */
status validate_files(SSl **head2, f_list **head);

int backup_file_list(SSl **head2, create_database *hash);

m_node *main_sub_nodecreate(char str[], f_list *temp);

status read_and_validate(int argc, char *argv[], f_list **head);

status open_files(char *argv);

status create_db(f_list *head, create_database *hash);

status Display(create_database *hash, f_list *head);

status search(char str[], create_database *hash, f_list *head);

status save_database(create_database *hash, char str[]);

status update_dabase(create_database *, f_list **);

#endif
