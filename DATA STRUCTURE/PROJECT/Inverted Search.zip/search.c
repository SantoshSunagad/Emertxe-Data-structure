#include "main.h"
/* Function Definition For Search the word in Database */
status search(char str[], create_database *hash, f_list *head)
{
	int key = tolower(str[0]) % 97;
	if (head == NULL)
	{
		return LIST_EMPTY;
	}

	if (hash[key].m_link != NULL)
	{

		m_node *m_temp = hash[key].m_link;
		while (m_temp)
		{
			/* String compare in  main node */
			if (strcmp(str, m_temp->word) == 0)
			{
				printf("word %s is present in %d file's\n", str, m_temp->file_count);

				s_node *s_temp = m_temp->m_sub_link;
				while (s_temp)
				{
					printf("In file: %s %d time's\n", s_temp->file_name, s_temp->word_count);
					s_temp = s_temp->s_sub_link;
				}
				return e_success;
			}
			m_temp = m_temp->m_main_link;
		}
	}
	return DATA_NOT_FOUND;
}
