#include "main.h"
/* Function Definition For Upadte the Database */
status update_dabase(create_database *hash, f_list **head)
{
	int index;
	char backup[30];

	printf("Enter the backup file name:");
	scanf("%s", backup);

	FILE *fptr = fopen(backup, "r");
	if (fptr == NULL)
	{
		printf("INFO: File Not Found\n");
		return e_failure;
	}
	/* Build the Database through the backup File */
	while (fscanf(fptr, "%s", backup) != EOF)
	{
		if (backup[0] == '#')
		{
			index = atoi(strtok(&backup[1], ":"));
			continue;
		}

		/*  main node */
		m_node *m_new = malloc(sizeof(m_node));
		if (m_new == NULL)
		{
			return e_failure;
		}
		m_new->m_main_link = NULL;
		strcpy(m_new->word, strtok(backup, ":"));
		m_new->file_count = atoi(strtok(NULL, ":"));
		/* sub word node */
		s_node *s_new = malloc(sizeof(s_node));
		s_node *stemp;
		if (s_new == NULL)
		{
			return e_failure;
		}
		s_new->s_sub_link = NULL;
		strcpy(s_new->file_name, strtok(NULL, ":")); 
		s_new->word_count = atoi(strtok(NULL, ":"));
		m_new->m_sub_link = s_new;
		stemp = s_new;

		/*Loop to create sub nodes  file count*/
		for (int i = 0; i < (m_new->file_count) - 1; i++)
		{
			s_node *s_new = malloc(sizeof(s_node));
			if (s_new == NULL)
			{
				return e_failure;
			}
			s_new->s_sub_link = NULL;
			strcpy(s_new->file_name, (strtok(NULL, ":")));
			s_new->word_count = atoi(strtok(NULL, ":"));
			stemp->s_sub_link = s_new;
			stemp = s_new;
		}
		
		/* attach the new main node into the hashtable*/
		m_node *temp = hash[index].m_link;
		if (temp == NULL)
		{
			hash[index].m_link = m_new;
		}
		else
		{
			while (temp->m_main_link)
			{
				temp = temp->m_main_link;
			}
			temp->m_main_link = m_new;
		}
	}
	fclose(fptr);
	return e_success;
}
